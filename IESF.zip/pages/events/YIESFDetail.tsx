// ================================================================
// YIESFDetail.tsx  (BARU — slim wrapper)
// Path: src/pages/events/YIESFDetail.tsx
//
// Cukup import data & template. Tidak ada logic di sini.
// Untuk event baru, copy pola ini dan ganti slug + data.
// ================================================================

import EventDetailPage from "./EventDetailPage";
import yiesf from "@/config/events/yiesf";

const YIESFDetail = () => <EventDetailPage slug="yiesf-2026" data={yiesf} />;

export default YIESFDetail;